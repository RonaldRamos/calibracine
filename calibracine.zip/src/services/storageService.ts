import {
  User,
  Cinema,
  Sala,
  EquipmentModel,
  MaintenanceReport,
  ActivityLog,
  CompanyConfig,
  DashboardStats,
} from '../types';
import {
  SEED_COMPANY_CONFIG,
  SEED_USERS,
  SEED_CINEMAS,
  SEED_SALAS,
  SEED_MODELS,
  SEED_REPORTS,
  SEED_LOGS,
} from '../data/seed';

const STORAGE_KEYS = {
  CURRENT_USER: 'cmm_current_user',
  USERS: 'cmm_users',
  CINEMAS: 'cmm_cinemas',
  SALAS: 'cmm_salas',
  MODELS: 'cmm_models',
  REPORTS: 'cmm_reports',
  LOGS: 'cmm_logs',
  COMPANY_CONFIG: 'cmm_company_config',
  THEME: 'cmm_theme',
};

// Initialize Storage with seed data if empty
export function initStorage(): void {
  if (typeof window === 'undefined') return;

  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(SEED_USERS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.CINEMAS)) {
    localStorage.setItem(STORAGE_KEYS.CINEMAS, JSON.stringify(SEED_CINEMAS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.SALAS)) {
    localStorage.setItem(STORAGE_KEYS.SALAS, JSON.stringify(SEED_SALAS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.MODELS)) {
    localStorage.setItem(STORAGE_KEYS.MODELS, JSON.stringify(SEED_MODELS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.REPORTS)) {
    localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(SEED_REPORTS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.LOGS)) {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(SEED_LOGS));
  }

  if (!localStorage.getItem(STORAGE_KEYS.COMPANY_CONFIG)) {
    localStorage.setItem(STORAGE_KEYS.COMPANY_CONFIG, JSON.stringify(SEED_COMPANY_CONFIG));
  }

  if (!localStorage.getItem(STORAGE_KEYS.CURRENT_USER)) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(SEED_USERS[0]));
  }
}

// Auth / Current User
export function getCurrentUser(): User | null {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
  return raw ? JSON.parse(raw) : null;
}

export function setCurrentUser(user: User | null): void {
  if (user) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
}

// Users
export function getUsers(): User[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.USERS);
  return raw ? JSON.parse(raw) : [];
}

export function saveUser(user: User): User {
  const users = getUsers();
  const index = users.findIndex((u) => u.id === user.id);
  if (index >= 0) {
    users[index] = user;
  } else {
    users.unshift(user);
  }
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
  return user;
}

export function deleteUser(id: string): void {
  const users = getUsers().filter((u) => u.id !== id);
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

// Cinemas
export function getCinemas(): Cinema[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.CINEMAS);
  return raw ? JSON.parse(raw) : [];
}

export function saveCinema(cinema: Cinema): Cinema {
  const cinemas = getCinemas();
  const index = cinemas.findIndex((c) => c.id === cinema.id);
  if (index >= 0) {
    cinemas[index] = cinema;
  } else {
    cinemas.unshift(cinema);
  }
  localStorage.setItem(STORAGE_KEYS.CINEMAS, JSON.stringify(cinemas));
  return cinema;
}

export function deleteCinema(id: string): void {
  const cinemas = getCinemas().filter((c) => c.id !== id);
  localStorage.setItem(STORAGE_KEYS.CINEMAS, JSON.stringify(cinemas));
  // Also clean up salas associated with this cinema
  const salas = getSalas().filter((s) => s.cinemaId !== id);
  localStorage.setItem(STORAGE_KEYS.SALAS, JSON.stringify(salas));
}

// Salas
export function getSalas(): Sala[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.SALAS);
  return raw ? JSON.parse(raw) : [];
}

export function saveSala(sala: Sala): Sala {
  const salas = getSalas();
  const cinemas = getCinemas();
  const cinema = cinemas.find((c) => c.id === sala.cinemaId);
  if (cinema) {
    sala.cinemaName = cinema.name;
  }

  const index = salas.findIndex((s) => s.id === sala.id);
  if (index >= 0) {
    salas[index] = sala;
  } else {
    salas.unshift(sala);
  }
  localStorage.setItem(STORAGE_KEYS.SALAS, JSON.stringify(salas));
  return sala;
}

export function deleteSala(id: string): void {
  const salas = getSalas().filter((s) => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.SALAS, JSON.stringify(salas));
}

// Models
export function getEquipmentModels(): EquipmentModel[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.MODELS);
  return raw ? JSON.parse(raw) : [];
}

export function saveEquipmentModel(model: EquipmentModel): EquipmentModel {
  const models = getEquipmentModels();
  const index = models.findIndex((m) => m.id === model.id);
  if (index >= 0) {
    models[index] = model;
  } else {
    models.unshift(model);
  }
  localStorage.setItem(STORAGE_KEYS.MODELS, JSON.stringify(models));
  return model;
}

export function deleteEquipmentModel(id: string): void {
  const models = getEquipmentModels().filter((m) => m.id !== id);
  localStorage.setItem(STORAGE_KEYS.MODELS, JSON.stringify(models));
}

// Maintenance Reports
export function getReports(): MaintenanceReport[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.REPORTS);
  return raw ? JSON.parse(raw) : [];
}

export function getReportById(id: string): MaintenanceReport | undefined {
  return getReports().find((r) => r.id === id);
}

export function saveReport(report: MaintenanceReport): MaintenanceReport {
  const reports = getReports();
  const index = reports.findIndex((r) => r.id === report.id);
  if (index >= 0) {
    reports[index] = { ...report, updatedAt: new Date().toISOString() };
  } else {
    reports.unshift({
      ...report,
      createdAt: report.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }
  localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
  return report;
}

export function deleteReport(id: string): void {
  const reports = getReports().filter((r) => r.id !== id);
  localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(reports));
}

// Company Config
export function getCompanyConfig(): CompanyConfig {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.COMPANY_CONFIG);
  return raw ? JSON.parse(raw) : SEED_COMPANY_CONFIG;
}

export function saveCompanyConfig(config: CompanyConfig): CompanyConfig {
  localStorage.setItem(STORAGE_KEYS.COMPANY_CONFIG, JSON.stringify(config));
  return config;
}

// Activity Logs
export function getActivityLogs(): ActivityLog[] {
  initStorage();
  const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
  return raw ? JSON.parse(raw) : [];
}

export function addActivityLog(action: string, details: string, user?: User | null): void {
  const logs = getActivityLogs();
  const activeUser = user || getCurrentUser();
  const newLog: ActivityLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    userId: activeUser?.id || 'sys',
    userName: activeUser?.name || 'Sistema',
    userRole: activeUser?.role || 'admin',
    action,
    details,
    timestamp: new Date().toISOString(),
  };
  logs.unshift(newLog);
  // Keep max 200 logs
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs.slice(0, 200)));
}

// Stats for Dashboard
export function getDashboardStats(): DashboardStats {
  const cinemas = getCinemas();
  const salas = getSalas();
  const users = getUsers();
  const reports = getReports();

  const technicians = users.filter((u) => u.role === 'technician');

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.substring(0, 7);

  const reportsToday = reports.filter((r) => r.date === todayStr).length;
  const reportsThisMonth = reports.filter((r) => r.date?.startsWith(currentMonthStr)).length;

  let totalEquipments = 0;
  let totalPhotos = 0;

  reports.forEach((r) => {
    totalEquipments += r.equipmentItems ? r.equipmentItems.length : 0;
    totalPhotos += r.photos ? r.photos.length : 0;
  });

  return {
    totalCinemas: cinemas.length,
    totalSalas: salas.length,
    totalTechnicians: technicians.length,
    totalReports: reports.length,
    reportsToday,
    reportsThisMonth,
    totalEquipments,
    totalPhotos,
  };
}

// Backup & Restore
export function exportDatabaseJSON(): string {
  initStorage();
  const data = {
    version: '1.0',
    exportedAt: new Date().toISOString(),
    companyConfig: getCompanyConfig(),
    users: getUsers(),
    cinemas: getCinemas(),
    salas: getSalas(),
    models: getEquipmentModels(),
    reports: getReports(),
    logs: getActivityLogs(),
  };
  return JSON.stringify(data, null, 2);
}

export function importDatabaseJSON(jsonStr: string): boolean {
  try {
    const parsed = JSON.parse(jsonStr);
    if (parsed.users && parsed.cinemas && parsed.reports) {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(parsed.users));
      localStorage.setItem(STORAGE_KEYS.CINEMAS, JSON.stringify(parsed.cinemas));
      localStorage.setItem(STORAGE_KEYS.SALAS, JSON.stringify(parsed.salas || []));
      localStorage.setItem(STORAGE_KEYS.MODELS, JSON.stringify(parsed.models || []));
      localStorage.setItem(STORAGE_KEYS.REPORTS, JSON.stringify(parsed.reports));
      if (parsed.companyConfig) {
        localStorage.setItem(STORAGE_KEYS.COMPANY_CONFIG, JSON.stringify(parsed.companyConfig));
      }
      if (parsed.logs) {
        localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(parsed.logs));
      }
      return true;
    }
    return false;
  } catch (err) {
    console.error('Error importing DB JSON:', err);
    return false;
  }
}
