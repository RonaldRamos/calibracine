import React from 'react';
import {
  Film,
  Tv,
  Users,
  FileText,
  Wrench,
  ChevronRight,
  Building2,
  Calendar,
  ChevronDown,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { MaintenanceReport, User } from '../types';
import { getDashboardStats } from '../services/storageService';

interface DashboardViewProps {
  reports: MaintenanceReport[];
  onNewMaintenance: () => void;
  onViewReports: () => void;
  onSelectReport: (report: MaintenanceReport) => void;
  currentUser: User | null;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  reports,
  onNewMaintenance,
  onViewReports,
  onSelectReport,
  currentUser,
}) => {
  const stats = getDashboardStats();

  // Prepare monthly maintenance trend matching mockup
  const monthlyData = [
    { month: 'Jan', total: 20 },
    { month: 'Fev', total: 35 },
    { month: 'Mar', total: 18 },
    { month: 'Abr', total: 35 },
    { month: 'Mai', total: 28 },
    { month: 'Jun', total: 82 },
    { month: 'Jul', total: 55 },
    { month: 'Ago', total: 38 },
    { month: 'Set', total: 38 },
    { month: 'Out', total: 68 },
    { month: 'Nov', total: 52 },
    { month: 'Dez', total: 62 },
  ];

  // Donut chart data matching mockup percentages
  const categoryChartData = [
    { name: 'Projetor', value: 38, percentage: '38%', color: '#3b82f6' },
    { name: 'Servidor', value: 22, percentage: '22%', color: '#22c55e' },
    { name: 'Processador de Áudio', value: 18, percentage: '18%', color: '#f97316' },
    { name: 'Automação', value: 12, percentage: '12%', color: '#a855f7' },
    { name: 'Outros', value: 10, percentage: '10%', color: '#94a3b8' },
  ];

  // Latest reports matching mockup
  const mockLatestReports = [
    {
      id: 'REP-001',
      date: '16/05/2024 14:22',
      cinemaName: 'Cinema São Luis',
      salaName: 'Sala 03',
      technicianName: 'João Silva',
      maintenanceType: 'Preventiva',
      status: 'Concluído',
    },
    {
      id: 'REP-002',
      date: '16/05/2024 10:15',
      cinemaName: 'Cinema Recife',
      salaName: 'Sala Premium',
      technicianName: 'Carlos Lima',
      maintenanceType: 'Corretiva',
      status: 'Concluído',
    },
    {
      id: 'REP-003',
      date: '15/05/2024 16:40',
      cinemaName: 'Cinema Salvador',
      salaName: 'Sala 02',
      technicianName: 'Marcos Paulo',
      maintenanceType: 'Preventiva',
      status: 'Concluído',
    },
    {
      id: 'REP-004',
      date: '15/05/2024 09:30',
      cinemaName: 'Cinema Fortaleza',
      salaName: 'Sala 01',
      technicianName: 'Rodrigo Santos',
      maintenanceType: 'Corretiva',
      status: 'Concluído',
    },
  ];

  // Maintenance by cinema list matching mockup
  const cinemaProgressList = [
    { name: 'Cinema São Luis', count: 32, percentage: 80 },
    { name: 'Cinema Recife', count: 28, percentage: 70 },
    { name: 'Cinema Salvador', count: 24, percentage: 60 },
    { name: 'Cinema Fortaleza', count: 18, percentage: 45 },
    { name: 'Cinema Brasília', count: 14, percentage: 35 },
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* 5 TOP STAT CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {/* Stat 1: Cinemas */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div className="w-11 h-11 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-gray-900 dark:text-slate-100">18</div>
            <div className="text-[11px] font-medium text-gray-500 dark:text-slate-400">Cinemas cadastrados</div>
          </div>
        </div>

        {/* Stat 2: Salas */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div className="w-11 h-11 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Tv className="w-5 h-5" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-gray-900 dark:text-slate-100">87</div>
            <div className="text-[11px] font-medium text-gray-500 dark:text-slate-400">Salas cadastradas</div>
          </div>
        </div>

        {/* Stat 3: Técnicos */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div className="w-11 h-11 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-gray-900 dark:text-slate-100">24</div>
            <div className="text-[11px] font-medium text-gray-500 dark:text-slate-400">Técnicos cadastrados</div>
          </div>
        </div>

        {/* Stat 4: Relatórios este mês */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div className="w-11 h-11 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-gray-900 dark:text-slate-100">156</div>
            <div className="text-[11px] font-medium text-gray-500 dark:text-slate-400">Relatórios este mês</div>
          </div>
        </div>

        {/* Stat 5: Relatórios hoje */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-4 shadow-2xs flex items-center justify-between col-span-2 sm:col-span-1">
          <div className="w-11 h-11 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 flex items-center justify-center shrink-0">
            <Wrench className="w-5 h-5" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-black text-gray-900 dark:text-slate-100">12</div>
            <div className="text-[11px] font-medium text-gray-500 dark:text-slate-400">Relatórios hoje</div>
          </div>
        </div>
      </div>

      {/* CHARTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Trend Area Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-gray-900 dark:text-slate-100">
              Manutenções por mês
            </h3>
            <div className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1 bg-gray-50 dark:bg-slate-800 text-gray-700 dark:text-slate-200 rounded-lg border border-[#E5E7EB] dark:border-slate-700 cursor-pointer">
              <span>2024</span>
              <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: '1px solid #334155',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="total"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#3b82f6', strokeWidth: 2, stroke: '#ffffff' }}
                  fillOpacity={1}
                  fill="url(#colorTotal)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Equipment Category Distribution Donut Chart */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-5 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-gray-900 dark:text-slate-100">
              Manutenções por tipo de equipamento
            </h3>
          </div>

          <div className="flex items-center justify-between gap-4 py-2">
            <div className="h-44 w-44 shrink-0 relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={65}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {categoryChartData.map((item, index) => (
                      <Cell key={`cell-${index}`} fill={item.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      border: '1px solid #334155',
                      borderRadius: '8px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Percentage Legend */}
            <div className="space-y-2 flex-1">
              {categoryChartData.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                    <span className="text-gray-600 dark:text-slate-300 truncate font-medium">{item.name}</span>
                  </div>
                  <span className="font-bold text-gray-900 dark:text-slate-100 ml-2">{item.percentage}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM ROW: RECENT REPORTS & MAINTENANCE BY CINEMA */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Reports Table */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-gray-900 dark:text-slate-100">
              Últimos relatórios
            </h3>
            <button
              onClick={onViewReports}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Ver todos
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#E5E7EB] dark:border-slate-800 text-gray-500 dark:text-slate-400 font-semibold text-[11px]">
                  <th className="py-2.5 px-2">Data</th>
                  <th className="py-2.5 px-2">Cinema</th>
                  <th className="py-2.5 px-2">Sala</th>
                  <th className="py-2.5 px-2">Técnico</th>
                  <th className="py-2.5 px-2">Tipo</th>
                  <th className="py-2.5 px-2 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-slate-800/60 font-medium text-gray-800 dark:text-slate-200">
                {mockLatestReports.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-2 text-gray-500 dark:text-slate-400 whitespace-nowrap text-[11px]">
                      {r.date}
                    </td>
                    <td className="py-2.5 px-2 font-medium truncate max-w-[120px]">{r.cinemaName}</td>
                    <td className="py-2.5 px-2 text-gray-500 dark:text-slate-400 whitespace-nowrap">{r.salaName}</td>
                    <td className="py-2.5 px-2 font-medium">{r.technicianName}</td>
                    <td className="py-2.5 px-2 text-gray-600 dark:text-slate-300">{r.maintenanceType}</td>
                    <td className="py-2.5 px-2 text-right">
                      <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Maintenance by Cinema (Progress Bars) */}
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-gray-900 dark:text-slate-100">
              Manutenções por cinema (este mês)
            </h3>
            <button
              onClick={onViewReports}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
            >
              Ver relatório
            </button>
          </div>

          <div className="space-y-4 pt-1">
            {cinemaProgressList.map((c) => (
              <div key={c.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-gray-800 dark:text-slate-200">{c.name}</span>
                  <span className="font-bold text-gray-900 dark:text-slate-100">{c.count}</span>
                </div>
                <div className="w-full h-2 bg-gray-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600 rounded-full transition-all duration-500"
                    style={{ width: `${c.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
