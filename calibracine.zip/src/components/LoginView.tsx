import React, { useState } from 'react';
import { Clapperboard, Lock, Mail, Shield, Wrench, ArrowRight, Eye, EyeOff, CheckSquare } from 'lucide-react';
import { User } from '../types';
import { getUsers, setCurrentUser, addActivityLog } from '../services/storageService';

interface LoginViewProps {
  onLoginSuccess: (user: User) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoverySuccess, setRecoverySuccess] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const users = getUsers();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase().trim());

    if (!user) {
      setErrorMessage('Usuário não encontrado. Use um dos botões de acesso rápido abaixo.');
      return;
    }

    if (user.status === 'inativo') {
      setErrorMessage('Esta conta de usuário está desativada no sistema.');
      return;
    }

    setCurrentUser(user);
    addActivityLog('LOGIN', `Acesso ao sistema efetuado por ${user.name}`, user);
    onLoginSuccess(user);
  };

  const handleQuickLogin = (role: 'admin' | 'technician') => {
    const users = getUsers();
    const targetUser = users.find((u) => u.role === role && u.status === 'ativo') || users[0];

    if (targetUser) {
      setCurrentUser(targetUser);
      addActivityLog('LOGIN_RAPIDO', `Acesso rápido efetuado no perfil de ${role.toUpperCase()}`, targetUser);
      onLoginSuccess(targetUser);
    }
  };

  const handleRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (recoveryEmail) {
      setRecoverySuccess(true);
      setTimeout(() => {
        setRecoverySuccess(false);
        setShowRecoveryModal(false);
        setRecoveryEmail('');
      }, 2500);
    }
  };

  return (
    <div className="min-h-screen bg-[#F9FAFB] dark:bg-slate-950 flex flex-col justify-center items-center p-4 sm:p-6 relative">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-xl p-6 sm:p-8 shadow-sm relative z-10">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center mx-auto mb-3 text-white shadow-md shadow-blue-600/30">
            <Clapperboard className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-black text-gray-900 dark:text-white tracking-tight">CalibraCine</h1>
          <p className="text-xs text-gray-500 dark:text-slate-400 font-medium mt-1">
            Gestão & Calibração de Cinema • Ronald Ramos
          </p>
        </div>

        {/* Quick Demo Access Buttons */}
        <div className="mb-6 p-3 bg-gray-50 dark:bg-slate-850/80 border border-[#E5E7EB] dark:border-slate-800 rounded-lg space-y-2">
          <p className="text-[11px] font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400 text-center">
            Acesso Rápido para Avaliação
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handleQuickLogin('admin')}
              className="flex items-center justify-center gap-1.5 py-2 px-3 bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-900/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-md text-xs font-semibold transition-colors cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              Entrar como Admin
            </button>
            <button
              type="button"
              onClick={() => handleQuickLogin('technician')}
              className="flex items-center justify-center gap-1.5 py-2 px-3 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/60 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800 rounded-md text-xs font-semibold transition-colors cursor-pointer"
            >
              <Wrench className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              Entrar como Técnico
            </button>
          </div>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-red-50 dark:bg-rose-950/60 border border-red-200 dark:border-rose-800 rounded-md text-xs font-medium text-red-700 dark:text-rose-300">
            {errorMessage}
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400 mb-1.5">
              E-mail de Acesso
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
              <input
                type="email"
                required
                placeholder="admin@cmm.com ou tecnico@cmm.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-3 py-2 bg-gray-50 dark:bg-slate-950 border border-[#E5E7EB] dark:border-slate-800 rounded-md text-gray-900 dark:text-slate-100 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-gray-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 dark:text-slate-400 mb-1.5">
              Senha
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2 bg-gray-50 dark:bg-slate-950 border border-[#E5E7EB] dark:border-slate-800 rounded-md text-gray-900 dark:text-slate-100 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-gray-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:text-slate-500 dark:hover:text-slate-300"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs">
            <label className="flex items-center gap-2 cursor-pointer text-gray-600 dark:text-slate-400 hover:text-gray-900 dark:hover:text-slate-200">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded border-[#E5E7EB] dark:border-slate-800 text-blue-600 focus:ring-blue-500/30"
              />
              <span>Lembrar acesso</span>
            </label>

            <button
              type="button"
              onClick={() => setShowRecoveryModal(true)}
              className="text-blue-600 dark:text-blue-400 hover:underline font-medium"
            >
              Recuperar senha?
            </button>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-medium shadow-xs flex items-center justify-center gap-2 transition-colors cursor-pointer mt-2"
          >
            <span>Entrar no Sistema</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-[#E5E7EB] dark:border-slate-800 text-center space-y-1">
          <p className="text-xs font-bold text-gray-800 dark:text-slate-200">
            CalibraCine v2.0
          </p>
          <p className="text-[11px] text-gray-500 dark:text-slate-400">
            Criado e desenvolvido por <strong>Ronald Ramos</strong>
          </p>
        </div>
      </div>

      {/* Password Recovery Modal */}
      {showRecoveryModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-xl p-6 w-full max-w-sm shadow-xl">
            <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">Recuperar Senha</h3>
            <p className="text-xs text-gray-500 dark:text-slate-400 mb-4">
              Informe seu e-mail cadastrado para receber as instruções de redefinição de acesso.
            </p>

            {recoverySuccess ? (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-md text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2 font-medium">
                <CheckSquare className="w-4 h-4" />
                <span>Instruções enviadas com sucesso para o e-mail!</span>
              </div>
            ) : (
              <form onSubmit={handleRecoverySubmit} className="space-y-4">
                <input
                  type="email"
                  required
                  placeholder="seu-email@cmm.com"
                  value={recoveryEmail}
                  onChange={(e) => setRecoveryEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-slate-950 border border-[#E5E7EB] dark:border-slate-800 rounded-md text-gray-900 dark:text-white text-xs"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowRecoveryModal(false)}
                    className="px-3 py-2 text-xs font-medium text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-md text-xs transition-colors"
                  >
                    Enviar Link
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
