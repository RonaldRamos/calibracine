import React, { useState, useEffect, useRef } from 'react';
import {
  Wrench,
  Camera,
  Upload,
  X,
  Plus,
  Trash2,
  FileCheck,
  Save,
  FileDown,
  CheckCircle,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import {
  Cinema,
  Sala,
  User,
  EquipmentCategory,
  EquipmentMaintenanceItem,
  EquipmentStatus,
  MaintenanceReport,
  MaintenanceType,
  EquipmentModel,
} from '../types';
import {
  getCinemas,
  getSalas,
  getEquipmentModels,
  getCompanyConfig,
  saveReport,
  addActivityLog,
} from '../services/storageService';
import { SignaturePad } from './SignaturePad';
import { generateReportPDF } from '../utils/pdfGenerator';

interface NewMaintenanceViewProps {
  currentUser: User | null;
  onReportSubmitted: (report: MaintenanceReport) => void;
  onCancel: () => void;
}

export const NewMaintenanceView: React.FC<NewMaintenanceViewProps> = ({
  currentUser,
  onReportSubmitted,
  onCancel,
}) => {
  const cinemas = getCinemas();
  const allSalas = getSalas();
  const availableModels = getEquipmentModels();

  // Basic info state
  const [technicianName, setTechnicianName] = useState(currentUser?.name || '');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState(
    new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  );
  const [selectedCinemaId, setSelectedCinemaId] = useState<string>(cinemas[0]?.id || '');
  const [filteredSalas, setFilteredSalas] = useState<Sala[]>([]);
  const [selectedSalaId, setSelectedSalaId] = useState<string>('');
  const [maintenanceType, setMaintenanceType] = useState<MaintenanceType>('Preventiva');
  const [generalDescription, setGeneralDescription] = useState('');

  // Category checkboxes
  const [selectedCategories, setSelectedCategories] = useState<Record<EquipmentCategory, boolean>>({
    projetor: true,
    servidor: false,
    processador: false,
    automacao: false,
    outros: false,
  });

  // Equipment maintenance items
  const [equipmentItems, setEquipmentItems] = useState<EquipmentMaintenanceItem[]>([
    {
      id: `item-${Date.now()}-1`,
      category: 'projetor',
      model: availableModels.find((m) => m.category === 'projetor')?.model || 'Barco SP4K',
      assetNumber: '',
      serialNumber: '',
      description: '',
      partsReplaced: '',
      timeSpentMinutes: 30,
      status: 'Funcionando',
    },
  ]);

  // Photos state (Data URLs)
  const [photos, setPhotos] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Digital Signature State
  const [digitalSignature, setDigitalSignature] = useState<string>('');

  // Filter available models specifically for the selected cinema (or global models)
  const cinemaModels = availableModels.filter(
    (m) => !m.cinemaId || m.cinemaId === selectedCinemaId
  );

  // Submission alert state
  const [validationError, setValidationError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedReportModal, setSubmittedReportModal] = useState<MaintenanceReport | null>(null);

  // Update filtered salas whenever selected cinema changes
  useEffect(() => {
    if (selectedCinemaId) {
      const salasForCinema = allSalas.filter((s) => s.cinemaId === selectedCinemaId);
      setFilteredSalas(salasForCinema);
      if (salasForCinema.length > 0) {
        setSelectedSalaId(salasForCinema[0].id);
      } else {
        setSelectedSalaId('');
      }
    }
  }, [selectedCinemaId]);

  // Handle Category Checkbox Toggle
  const handleCategoryToggle = (cat: EquipmentCategory) => {
    const isNowChecked = !selectedCategories[cat];
    setSelectedCategories((prev) => ({ ...prev, [cat]: isNowChecked }));

    if (isNowChecked) {
      // Add a default item block for this category
      const defaultModel = availableModels.find((m) => m.category === cat)?.model || 'Modelo Genérico';
      setEquipmentItems((prev) => [
        ...prev,
        {
          id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          category: cat,
          model: defaultModel,
          assetNumber: '',
          serialNumber: '',
          description: '',
          partsReplaced: '',
          timeSpentMinutes: 30,
          status: 'Funcionando',
        },
      ]);
    } else {
      // Remove all items for this category
      setEquipmentItems((prev) => prev.filter((item) => item.category !== cat));
    }
  };

  // Add another item block for a specific category
  const handleAddEquipmentBlock = (cat: EquipmentCategory) => {
    const defaultModel = availableModels.find((m) => m.category === cat)?.model || 'Modelo Customizado';
    setEquipmentItems((prev) => [
      ...prev,
      {
        id: `item-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        category: cat,
        model: defaultModel,
        assetNumber: '',
        serialNumber: '',
        description: '',
        partsReplaced: '',
        timeSpentMinutes: 30,
        status: 'Funcionando',
      },
    ]);
  };

  // Remove individual equipment item block
  const handleRemoveEquipmentBlock = (id: string) => {
    setEquipmentItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Update equipment item field
  const handleUpdateItemField = (id: string, field: keyof EquipmentMaintenanceItem, value: any) => {
    setEquipmentItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  // Photo Upload Handler (Camera, Gallery, Drag-Drop)
  const handlePhotoUpload = (files: FileList | null) => {
    if (!files) return;

    const currentPhotos = [...photos];
    const remainingSlot = 20 - currentPhotos.length;

    if (remainingSlot <= 0) {
      alert('Limite máximo de 20 fotos atingido para este relatório.');
      return;
    }

    const fileArray = Array.from(files).slice(0, remainingSlot);

    fileArray.forEach((file) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (reader.result) {
          setPhotos((prev) => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Drag & Drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    handlePhotoUpload(e.dataTransfer.files);
  };

  // Form Submission
  const handleSubmitReport = async (asDraft: boolean = false) => {
    setValidationError('');

    const currentCinema = cinemas.find((c) => c.id === selectedCinemaId);
    const currentSala = allSalas.find((s) => s.id === selectedSalaId);

    if (!currentCinema) {
      setValidationError('Selecione um Cinema válido.');
      return;
    }

    if (!currentSala) {
      setValidationError('Selecione uma Sala válida para o cinema.');
      return;
    }

    if (!asDraft && equipmentItems.length === 0) {
      setValidationError('Selecione ao menos uma categoria de equipamento e preencha os dados.');
      return;
    }

    setIsSubmitting(true);

    const reportId = `CMM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReport: MaintenanceReport = {
      id: reportId,
      technicianId: currentUser?.id || 'tec-1',
      technicianName,
      date,
      time,
      cinemaId: currentCinema.id,
      cinemaName: currentCinema.name,
      salaId: currentSala.id,
      salaName: currentSala.name,
      salaType: currentSala.type,
      maintenanceType,
      generalDescription,
      equipmentItems,
      photos,
      digitalSignature,
      status: asDraft ? 'draft' : 'submitted',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveReport(newReport);
    addActivityLog(
      asDraft ? 'SALVAR_RASCUNHO' : 'ENVIAR_RELATORIO',
      `Relatório ${newReport.id} (${asDraft ? 'Rascunho' : 'Finalizado'}) enviado para ${currentCinema.name} - ${currentSala.name}`,
      currentUser
    );

    setIsSubmitting(false);

    if (asDraft) {
      onReportSubmitted(newReport);
    } else {
      setSubmittedReportModal(newReport);
    }
  };

  // Instant PDF Preview/Download
  const handleGeneratePDF = async () => {
    const currentCinema = cinemas.find((c) => c.id === selectedCinemaId);
    const currentSala = allSalas.find((s) => s.id === selectedSalaId);
    const company = getCompanyConfig();

    const tempReport: MaintenanceReport = {
      id: `PREVIEW-${Math.floor(100 + Math.random() * 900)}`,
      technicianId: currentUser?.id || 'tec-1',
      technicianName,
      date,
      time,
      cinemaId: currentCinema?.id || '',
      cinemaName: currentCinema?.name || 'Cinema',
      salaId: currentSala?.id || '',
      salaName: currentSala?.name || 'Sala',
      salaType: currentSala?.type || 'Convencional',
      maintenanceType,
      generalDescription,
      equipmentItems,
      photos,
      digitalSignature,
      status: 'submitted',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await generateReportPDF(tempReport, company);
  };

  // Step Wizard state matching mockup panels
  const [activeStep, setActiveStep] = useState<number>(1);

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* STEP WIZARD NAVIGATION TABS */}
      <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-2 shadow-2xs flex overflow-x-auto scrollbar-none">
        {[
          { num: 1, title: 'Dados gerais' },
          { num: 2, title: 'Equipamentos' },
          { num: 3, title: 'Fotos' },
          { num: 4, title: 'Assinatura' },
          { num: 5, title: 'Relatório (PDF)' },
        ].map((step) => {
          const isActive = activeStep === step.num;
          return (
            <button
              key={step.num}
              type="button"
              onClick={() => setActiveStep(step.num)}
              className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-gray-600 dark:text-slate-400 hover:bg-gray-50 dark:hover:bg-slate-800'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center ${
                  isActive ? 'bg-white text-blue-600 font-black' : 'bg-gray-200 dark:bg-slate-700 text-gray-700 dark:text-slate-300'
                }`}
              >
                {step.num}
              </span>
              <span className="truncate">{step.title}</span>
            </button>
          );
        })}
      </div>

      {validationError && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl text-xs font-semibold text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{validationError}</span>
        </div>
      )}

      {/* STEP 1: DADOS GERAIS */}
      {activeStep === 1 && (
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xs">
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-slate-100">Nova Manutenção</h2>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Preencha os dados da manutenção</p>
          </div>

          <div className="space-y-4 pt-2">
            <h3 className="text-xs font-bold text-gray-700 dark:text-slate-300 border-b border-gray-100 dark:border-slate-800 pb-2">
              Dados gerais
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Técnico *
                </label>
                <input
                  type="text"
                  value={technicianName}
                  onChange={(e) => setTechnicianName(e.target.value)}
                  placeholder="Ex: João Silva"
                  className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Data *
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Cinema *
                </label>
                <select
                  value={selectedCinemaId}
                  onChange={(e) => setSelectedCinemaId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                >
                  {cinemas.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Sala *
                </label>
                <select
                  value={selectedSalaId}
                  onChange={(e) => setSelectedSalaId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                >
                  {filteredSalas.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Tipo de manutenção *
                </label>
                <select
                  value={maintenanceType}
                  onChange={(e) => setMaintenanceType(e.target.value as MaintenanceType)}
                  className="w-full px-3.5 py-2.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                >
                  <option value="Preventiva">Preventiva</option>
                  <option value="Corretiva">Corretiva</option>
                  <option value="Emergencial">Emergencial</option>
                  <option value="Inspeção">Inspeção</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                  Descrição geral
                </label>
                <textarea
                  rows={3}
                  value={generalDescription}
                  onChange={(e) => setGeneralDescription(e.target.value)}
                  placeholder="Manutenção preventiva realizada conforme checklist mensal."
                  className="w-full p-3 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 bg-gray-100 dark:bg-slate-800 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
            >
              Cancelar
            </button>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleSubmitReport(true)}
                className="px-4 py-2 border border-[#E5E7EB] dark:border-slate-700 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
              >
                Salvar rascunho
              </button>
              <button
                type="button"
                onClick={() => setActiveStep(2)}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
              >
                Avançar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: EQUIPAMENTOS */}
      {activeStep === 2 && (
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xs">
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-slate-100">Equipamentos</h2>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Selecione e descreva os equipamentos</p>
          </div>

          {/* Pill Category Tabs */}
          <div className="flex flex-wrap gap-2 pt-1">
            {[
              { id: 'projetor', label: 'Projetor' },
              { id: 'servidor', label: 'Servidor' },
              { id: 'processador', label: 'Processador' },
              { id: 'automacao', label: 'Automação' },
              { id: 'outros', label: 'Outros' },
            ].map((cat) => {
              const isChecked = selectedCategories[cat.id as EquipmentCategory];
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleCategoryToggle(cat.id as EquipmentCategory)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    isChecked
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-gray-100 dark:bg-slate-800 text-gray-600 dark:text-slate-400 hover:bg-gray-200'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Equipment Fields */}
          <div className="space-y-4 pt-2">
            {equipmentItems.map((item, index) => (
              <div key={item.id} className="p-4 bg-gray-50 dark:bg-slate-850 rounded-xl border border-gray-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between border-b border-gray-200 dark:border-slate-700 pb-2">
                  <span className="text-xs font-bold text-gray-800 dark:text-slate-200 uppercase">
                    Item #{index + 1} ({item.category})
                  </span>
                  {equipmentItems.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveEquipmentBlock(item.id)}
                      className="text-rose-500 hover:text-rose-600 text-xs font-medium"
                    >
                      Remover
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                      Modelo do Equipamento ({item.category}) *
                    </label>
                    <select
                      value={item.model}
                      onChange={(e) => {
                        const val = e.target.value;
                        handleUpdateItemField(item.id, 'model', val);
                        const matchedModel = cinemaModels.find((m) => m.model === val);
                        if (matchedModel?.serialNumber) {
                          handleUpdateItemField(item.id, 'serialNumber', matchedModel.serialNumber);
                        }
                      }}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-semibold"
                    >
                      <option value="">Selecione o equipamento deste cinema...</option>
                      {cinemaModels
                        .filter((m) => m.category === item.category)
                        .map((m) => (
                          <option key={m.id} value={m.model}>
                            {m.brand} {m.model} {m.serialNumber ? `(S/N: ${m.serialNumber})` : ''}
                          </option>
                        ))}
                      {cinemaModels.filter((m) => m.category === item.category).length === 0 && (
                        <option value={item.model || 'Equipamento Padrão'}>
                          {item.model || 'Nenhum específico cadastrado - Digitar abaixo'}
                        </option>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                      Nº de Série
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: BKLD12345"
                      value={item.serialNumber || ''}
                      onChange={(e) => handleUpdateItemField(item.id, 'serialNumber', e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                    Descrição da manutenção *
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Limpeza dos filtros e lente. Verificação de foco e convergência. Teste de imagem OK."
                    value={item.description}
                    onChange={(e) => handleUpdateItemField(item.id, 'description', e.target.value)}
                    className="w-full p-2.5 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                      Peças substituídas
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Filtro modelo X2-100"
                      value={item.partsReplaced || ''}
                      onChange={(e) => handleUpdateItemField(item.id, 'partsReplaced', e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                      Status *
                    </label>
                    <select
                      value={item.status}
                      onChange={(e) =>
                        handleUpdateItemField(item.id, 'status', e.target.value as EquipmentStatus)
                      }
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                    >
                      <option value="Funcionando">Funcionando</option>
                      <option value="Funcionando com restrições">Funcionando c/ restrições</option>
                      <option value="Necessita reparo">Necessita reparo</option>
                      <option value="Parado">Parado</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 dark:text-slate-300 mb-1">
                      Tempo gasto (HH:MM)
                    </label>
                    <input
                      type="text"
                      placeholder="01:30"
                      onChange={(e) => {
                        const mins = parseInt(e.target.value) || 90;
                        handleUpdateItemField(item.id, 'timeSpentMinutes', mins);
                      }}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-700 rounded-xl text-xs text-gray-900 dark:text-slate-100 font-medium"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setActiveStep(1)}
              className="px-4 py-2 border border-[#E5E7EB] dark:border-slate-700 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
            >
              Voltar
            </button>
            <button
              type="button"
              onClick={() => setActiveStep(3)}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
            >
              Salvar e continuar
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: FOTOS */}
      {activeStep === 3 && (
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xs">
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-slate-100">Fotos</h2>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Adicione fotos da manutenção</p>
          </div>

          {/* Upload Area */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 dark:border-slate-700 hover:border-blue-500 rounded-2xl p-8 text-center bg-gray-50/50 dark:bg-slate-800/50 cursor-pointer transition-colors"
          >
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-xs font-bold text-gray-700 dark:text-slate-300">
              Arraste as fotos aqui
            </p>
            <p className="text-[11px] text-gray-500 mt-1">ou toque para selecionar (Máx. 20 fotos)</p>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => handlePhotoUpload(e.target.files)}
              className="hidden"
            />
          </div>

          {/* Photo Gallery Grid */}
          {photos.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {photos.map((photo, pIdx) => (
                <div key={pIdx} className="relative group border border-gray-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-900 aspect-square">
                  <img src={photo} alt={`Foto ${pIdx + 1}`} className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setPhotos((prev) => prev.filter((_, idx) => idx !== pIdx))}
                    className="absolute top-1.5 right-1.5 w-6 h-6 bg-slate-900/80 text-white rounded-full flex items-center justify-center text-xs"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setActiveStep(2)}
              className="px-4 py-2 border border-[#E5E7EB] dark:border-slate-700 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
            >
              Voltar
            </button>
            <button
              type="button"
              onClick={() => setActiveStep(4)}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
            >
              Salvar e continuar
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: ASSINATURA */}
      {activeStep === 4 && (
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xs">
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-slate-100">Assinatura</h2>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Assine abaixo com o dedo</p>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-2xl">
            <SignaturePad
              initialSignature={digitalSignature}
              onSave={(sig) => setDigitalSignature(sig)}
              onClear={() => setDigitalSignature('')}
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setActiveStep(3)}
              className="px-4 py-2 border border-[#E5E7EB] dark:border-slate-700 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
            >
              Voltar
            </button>
            <button
              type="button"
              onClick={() => {
                handleSubmitReport(false);
                setActiveStep(5);
              }}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
            >
              Finalizar
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: RELATÓRIO (PDF PREVIEW) */}
      {activeStep === 5 && (
        <div className="bg-white dark:bg-slate-900 border border-[#E5E7EB] dark:border-slate-800 rounded-2xl p-6 space-y-5 shadow-2xs">
          <div>
            <h2 className="text-base font-bold text-gray-900 dark:text-slate-100">Relatório (PDF Preview)</h2>
            <p className="text-xs text-gray-500 dark:text-slate-400 mt-0.5">Visualização do relatório</p>
          </div>

          {/* Paper Mockup Preview */}
          <div className="bg-white text-gray-900 border border-gray-200 rounded-2xl p-6 shadow-md max-w-xl mx-auto space-y-4 text-xs font-sans">
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 bg-blue-600 rounded-md flex items-center justify-center text-white font-black text-xs">
                  CMM
                </div>
                <div>
                  <div className="font-extrabold text-sm">RELATÓRIO DE MANUTENÇÃO</div>
                  <div className="text-[10px] text-gray-500">CINEMA MAINTENANCE MANAGER</div>
                </div>
              </div>
            </div>

            <div className="space-y-1 text-gray-700">
              <div><strong className="text-gray-900">Cinema:</strong> {cinemas.find(c => c.id === selectedCinemaId)?.name || 'Cinema São Luis'}</div>
              <div><strong className="text-gray-900">Sala:</strong> {filteredSalas.find(s => s.id === selectedSalaId)?.name || 'Sala 03'}</div>
              <div><strong className="text-gray-900">Data:</strong> {date} {time}</div>
              <div><strong className="text-gray-900">Técnico:</strong> {technicianName}</div>
              <div><strong className="text-gray-900">Tipo:</strong> {maintenanceType}</div>
            </div>

            <div className="border-t pt-2">
              <div className="font-bold uppercase text-[10px] text-gray-500 tracking-wider mb-1">EQUIPAMENTOS</div>
              {equipmentItems.map((item, idx) => (
                <div key={idx} className="bg-gray-50 p-2 rounded-lg text-[11px] mb-1">
                  <div><strong>{item.category.toUpperCase()}:</strong> {item.model}</div>
                  <div><strong>Descrição:</strong> {item.description || 'Limpeza e testes de convergência.'}</div>
                </div>
              ))}
            </div>

            {digitalSignature && (
              <div className="border-t pt-2">
                <div className="font-bold text-[10px] text-gray-500 mb-1">ASSINATURA DO TÉCNICO</div>
                <img src={digitalSignature} alt="Assinatura" className="h-10 object-contain" />
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 border border-[#E5E7EB] dark:border-slate-700 text-gray-700 dark:text-slate-300 rounded-xl text-xs font-medium"
            >
              Fechar
            </button>
            <button
              type="button"
              onClick={handleGeneratePDF}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-2"
            >
              <FileDown className="w-4 h-4" />
              <span>Baixar PDF</span>
            </button>
          </div>
        </div>
      )}

      {/* Submitted Report Success & Email Dispatch Modal */}
      {submittedReportModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-60">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 w-full max-w-lg shadow-2xl text-center space-y-5">
            <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto shadow-md shadow-emerald-500/20">
              <CheckCircle className="w-9 h-9" />
            </div>

            <div>
              <span className="px-2.5 py-1 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 font-mono font-bold text-xs rounded-md">
                {submittedReportModal.id}
              </span>
              <h3 className="text-lg font-black text-gray-900 dark:text-slate-100 mt-2">
                Relatório de Manutenção Enviado!
              </h3>
              <p className="text-xs text-gray-500 dark:text-slate-400 mt-1">
                {submittedReportModal.cinemaName} • {submittedReportModal.salaName}
              </p>
            </div>

            {/* Email dispatch feedback */}
            <div className="p-4 bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 rounded-xl text-left space-y-2 text-xs text-emerald-900 dark:text-emerald-200 font-medium">
              <div className="font-bold flex items-center gap-2 text-emerald-800 dark:text-emerald-300">
                <span>✉️ Cópias em PDF disparadas automaticamente por e-mail:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-emerald-700 dark:text-emerald-300 pl-1">
                <li>
                  Técnico: <strong>{currentUser?.email || submittedReportModal.technicianName}</strong>
                </li>
                <li>
                  Administrador: <strong>admin@calibracine.com</strong>
                </li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={async () => {
                  const company = getCompanyConfig();
                  await generateReportPDF(submittedReportModal, company);
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                <span>Baixar PDF Agora</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  const r = submittedReportModal;
                  setSubmittedReportModal(null);
                  onReportSubmitted(r);
                }}
                className="w-full sm:w-auto px-5 py-2.5 bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 text-gray-800 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Ver Relatórios
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
