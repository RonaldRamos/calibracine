import React from 'react';
import { Menu, Sun, Moon, Shield, Wrench, Search, Plus, Calendar, ChevronDown } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  onToggleSidebar: () => void;
  currentUser: User | null;
  onSwitchRole: () => void;
  activeTab: string;
  onNewMaintenance: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleSidebar,
  currentUser,
  onSwitchRole,
  activeTab,
  onNewMaintenance,
  isDarkMode,
  onToggleTheme,
  searchQuery,
  onSearchChange,
}) => {
  const isAdmin = currentUser?.role === 'admin';

  const tabTitles: Record<string, { title: string; subtitle: string }> = {
    dashboard: { title: 'Dashboard', subtitle: 'Visão geral do sistema' },
    nova_manutencao: { title: 'Nova Manutenção', subtitle: 'Preencha os dados da manutenção' },
    relatorios: { title: 'Relatórios', subtitle: 'Histórico e emissão de relatórios' },
    cinemas: { title: 'Cinemas', subtitle: 'Gestão de complexos de cinema' },
    salas: { title: 'Salas', subtitle: 'Gestão de salas de exibição' },
    equipamentos: { title: 'Equipamentos', subtitle: 'Catálogo de projetores, áudio e servidores' },
    tecnicos: { title: 'Técnicos', subtitle: 'Equipe técnica e especialistas' },
    logs: { title: 'Usuários & Logs', subtitle: 'Usuários do sistema e auditoria' },
    configuracoes: { title: 'Configurações', subtitle: 'Ajustes gerais do CalibraCine' },
    sobre: { title: 'Sobre o CalibraCine', subtitle: 'Informações do sistema e criador Ronald Ramos' },
    perfil: { title: 'Meu Perfil', subtitle: 'Dados da conta e preferências' },
  };

  const currentTabInfo = tabTitles[activeTab] || {
    title: 'Dashboard',
    subtitle: 'Visão geral do sistema',
  };

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-[#E5E7EB] dark:border-slate-800 sticky top-0 z-30 px-4 lg:px-8 flex items-center justify-between gap-4 transition-colors">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-lg text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          title="Abrir menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-base font-bold text-gray-900 dark:text-slate-100 leading-tight">
            {currentTabInfo.title}
          </h1>
          <p className="text-xs text-gray-500 dark:text-slate-400 hidden sm:block">
            {currentTabInfo.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* Date Selector Badge */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-lg text-xs font-medium text-gray-700 dark:text-slate-200 shadow-2xs">
          <Calendar className="w-3.5 h-3.5 text-gray-400 dark:text-slate-400" />
          <span>16 de Maio de 2024</span>
          <ChevronDown className="w-3 h-3 text-gray-400" />
        </div>

        {/* User Card */}
        <div className="flex items-center gap-2 px-2.5 py-1 bg-gray-50 dark:bg-slate-800 border border-[#E5E7EB] dark:border-slate-700 rounded-lg shadow-2xs">
          <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
            {currentUser?.name.substring(0, 1) || 'A'}
          </div>
          <div className="hidden sm:block text-left leading-tight pr-1">
            <span className="text-xs font-semibold text-gray-900 dark:text-slate-100 block">
              {currentUser?.name || 'Administrador'}
            </span>
            <span className="text-[10px] text-gray-500 dark:text-slate-400 block">
              {currentUser?.email || 'admin@cmm.com'}
            </span>
          </div>
        </div>

        {/* Quick Role Switcher */}
        <button
          onClick={onSwitchRole}
          title="Alternar entre modo Administrador e Técnico"
          className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
            isAdmin
              ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800 hover:bg-amber-100'
              : 'bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800 hover:bg-blue-100'
          }`}
        >
          {isAdmin ? <Shield className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" /> : <Wrench className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />}
          <span>{isAdmin ? 'Admin' : 'Técnico'}</span>
        </button>

        {/* Theme Toggle */}
        <button
          onClick={onToggleTheme}
          className="p-2 text-gray-600 dark:text-slate-300 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          title={isDarkMode ? 'Mudar para Modo Claro' : 'Mudar para Modo Escuro'}
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-gray-600" />}
        </button>
      </div>
    </header>
  );
};
