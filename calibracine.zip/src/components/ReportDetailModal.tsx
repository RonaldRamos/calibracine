import React, { useState } from 'react';
import {
  X,
  FileDown,
  Printer,
  Calendar,
  Clock,
  MapPin,
  Tv,
  User,
  ShieldAlert,
  Trash2,
  Maximize2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Mail,
  Send,
} from 'lucide-react';
import { MaintenanceReport, User as UserType } from '../types';
import { getCompanyConfig, deleteReport, addActivityLog } from '../services/storageService';
import { generateReportPDF } from '../utils/pdfGenerator';

interface ReportDetailModalProps {
  report: MaintenanceReport | null;
  onClose: () => void;
  currentUser: UserType | null;
  onReportDeleted?: () => void;
}

export const ReportDetailModal: React.FC<ReportDetailModalProps> = ({
  report,
  onClose,
  currentUser,
  onReportDeleted,
}) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [showEmailModal, setShowEmailModal] = useState<boolean>(false);
  const [recipientEmail, setRecipientEmail] = useState<string>(currentUser?.email || 'admin@calibracine.com');
  const [emailSuccess, setEmailSuccess] = useState<boolean>(false);

  if (!report) return null;

  const isAdmin = currentUser?.role === 'admin';
  const company = getCompanyConfig();

  const handleDownloadPDF = async () => {
    await generateReportPDF(report, company);
  };

  const handleSendEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientEmail) return;

    setEmailSuccess(true);
    addActivityLog('ENVIAR_EMAIL', `Cópia em PDF do relatório ${report.id} enviada para ${recipientEmail}`, currentUser);

    setTimeout(() => {
      setEmailSuccess(false);
      setShowEmailModal(false);
    }, 2200);
  };

  const handleDelete = () => {
    if (confirm(`Tem certeza que deseja excluir o relatório ${report.id}? Esta ação não pode ser desfeita.`)) {
      deleteReport(report.id);
      addActivityLog('EXCLUIR_RELATORIO', `Relatório ${report.id} excluído por ${currentUser?.name}`, currentUser);
      if (onReportDeleted) onReportDeleted();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative my-8">
        {/* Modal Header */}
        <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 bg-sky-600 text-white font-mono font-bold text-xs rounded-md">
                {report.id}
              </span>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                  report.status === 'submitted'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {report.status === 'submitted' ? 'Concluído' : 'Rascunho'}
              </span>
            </div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100 mt-1">
              {report.cinemaName} • {report.salaName}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setShowEmailModal(true)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <Mail className="w-4 h-4" />
              <span>Enviar E-mail</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPDF}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <FileDown className="w-4 h-4" />
              <span>Baixar PDF</span>
            </button>

            {isAdmin && (
              <button
                type="button"
                onClick={handleDelete}
                className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer"
                title="Excluir relatório"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50 dark:bg-slate-850 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Técnico</span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100">{report.technicianName}</span>
            </div>

            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Data e Hora</span>
              <span className="text-xs font-bold text-slate-900 dark:text-slate-100">
                {report.date} às {report.time}
              </span>
            </div>

            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Tipo Manutenção</span>
              <span className="text-xs font-bold text-sky-600 dark:text-sky-400">{report.maintenanceType}</span>
            </div>

            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Tipo de Sala</span>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">{report.salaType}</span>
            </div>
          </div>

          {/* General Description */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
              Descrição Geral e Diagnóstico
            </h3>
            <div className="p-4 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
              {report.generalDescription || 'Sem observações gerais.'}
            </div>
          </div>

          {/* Equipment Checklist */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
              Equipamentos Atendidos ({report.equipmentItems?.length || 0})
            </h3>

            <div className="space-y-3">
              {report.equipmentItems?.map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="p-4 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900 dark:text-slate-100">
                      #{idx + 1} {item.model}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.status === 'Funcionando'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300">{item.description}</p>

                  <div className="flex flex-wrap gap-4 text-[11px] text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-800">
                    {item.assetNumber && <span>Patrimônio: <strong className="text-slate-800 dark:text-slate-200">{item.assetNumber}</strong></span>}
                    {item.serialNumber && <span>S/N: <strong className="text-slate-800 dark:text-slate-200">{item.serialNumber}</strong></span>}
                    {item.partsReplaced && <span>Peças: <strong className="text-slate-800 dark:text-slate-200">{item.partsReplaced}</strong></span>}
                    <span>Tempo: <strong className="text-slate-800 dark:text-slate-200">{item.timeSpentMinutes} min</strong></span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Photo Gallery */}
          {report.photos && report.photos.length > 0 && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                Evidências Fotográficas ({report.photos.length})
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {report.photos.map((photo, pIdx) => (
                  <div
                    key={pIdx}
                    onClick={() => setSelectedPhoto(photo)}
                    className="relative group aspect-video rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 cursor-pointer"
                  >
                    <img src={photo} alt={`Foto ${pIdx + 1}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <Maximize2 className="w-5 h-5" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Digital Signature */}
          {report.digitalSignature && (
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Assinatura Digital do Técnico
              </h3>
              <div className="p-4 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 rounded-xl inline-block text-center">
                <img
                  src={report.digitalSignature}
                  alt="Assinatura"
                  className="max-h-20 max-w-xs object-contain mx-auto mb-2"
                />
                <div className="text-xs font-bold text-slate-900 dark:text-slate-100 border-t border-slate-200 dark:border-slate-800 pt-1">
                  {report.technicianName}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Lightbox for High-Res Photo View */}
      {selectedPhoto && (
        <div
          onClick={() => setSelectedPhoto(null)}
          className="fixed inset-0 bg-slate-950/90 flex items-center justify-center p-4 z-60 cursor-pointer"
        >
          <div className="relative max-w-3xl max-h-[85vh]">
            <img src={selectedPhoto} className="max-w-full max-h-[85vh] rounded-2xl object-contain shadow-2xl" />
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-2 right-2 p-2 bg-slate-900 text-white rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
      {/* Send Email Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-60">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-gray-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 rounded-lg flex items-center justify-center">
                  <Mail className="w-4.5 h-4.5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 dark:text-slate-100">Enviar Relatório por E-mail</h3>
                  <p className="text-[11px] text-gray-500 dark:text-slate-400">PDF do relatório {report.id}</p>
                </div>
              </div>
              <button
                onClick={() => setShowEmailModal(false)}
                className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {emailSuccess ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Cópia em PDF disparada com sucesso para <strong>{recipientEmail}</strong>!</span>
              </div>
            ) : (
              <form onSubmit={handleSendEmailSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-gray-700 dark:text-slate-300 mb-1">E-mail do Destinatário *</label>
                  <input
                    type="email"
                    required
                    placeholder="usuario@cinestar.com.br"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl font-semibold text-gray-900 dark:text-slate-100"
                  />
                </div>

                <div className="bg-gray-50 dark:bg-slate-850 p-3 rounded-xl border border-gray-200 dark:border-slate-800 space-y-1.5 text-[11px] text-gray-600 dark:text-slate-400">
                  <p className="font-bold text-gray-800 dark:text-slate-200">Destinatários Padrão do Sistema:</p>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setRecipientEmail(report.technicianName.includes('@') ? report.technicianName : 'roberto.tecnico@calibracine.com')}
                      className="text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                    >
                      Técnico Responsável
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => setRecipientEmail(company.email)}
                      className="text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                    >
                      Administrador ({company.email})
                    </button>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-gray-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowEmailModal(false)}
                    className="px-4 py-2 font-medium text-gray-500 dark:text-slate-400 hover:text-gray-900 dark:hover:text-white"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-xs flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Disparar E-mail</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
