import React, { useState, useRef } from 'react';
import {
  Settings,
  Building,
  Upload,
  Download,
  Database,
  CheckCircle,
  AlertTriangle,
  Moon,
  Sun,
  Globe,
} from 'lucide-react';
import { CompanyConfig, User } from '../types';
import {
  getCompanyConfig,
  saveCompanyConfig,
  exportDatabaseJSON,
  importDatabaseJSON,
  addActivityLog,
} from '../services/storageService';

interface SettingsViewProps {
  currentUser: User | null;
  onRefresh: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onRefresh,
  isDarkMode,
  onToggleTheme,
}) => {
  const [config, setConfig] = useState<CompanyConfig>(getCompanyConfig());
  const [saveSuccess, setSaveSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    saveCompanyConfig(config);
    addActivityLog('CONFIG_SISTEMA', `Configurações da empresa atualizadas por ${currentUser?.name}`, currentUser);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
    onRefresh();
  };

  const handleExportBackup = () => {
    const jsonStr = exportDatabaseJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CMM_Backup_Database_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content && importDatabaseJSON(content)) {
        alert('Banco de dados restaurado com sucesso!');
        onRefresh();
      } else {
        alert('Falha ao importar o arquivo de backup. Formato JSON inválido.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
        <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">
          Preferências Gerais
        </span>
        <h2 className="text-xl font-black text-slate-900 dark:text-slate-100">Configurações do Sistema</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Defina o cabeçalho dos relatórios em PDF, gerencie backups e escolha o tema visual.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>Configurações salvas com sucesso!</span>
        </div>
      )}

      {/* Company Info Form */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
          Dados da Empresa (Impressos no Cabeçalho do PDF)
        </h3>

        <form onSubmit={handleSaveConfig} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Nome da Empresa *</label>
              <input
                type="text"
                required
                value={config.name}
                onChange={(e) => setConfig({ ...config, name: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">CNPJ *</label>
              <input
                type="text"
                required
                value={config.cnpj}
                onChange={(e) => setConfig({ ...config, cnpj: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Telefone Suporte</label>
              <input
                type="text"
                value={config.phone}
                onChange={(e) => setConfig({ ...config, phone: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">E-mail Oficial</label>
              <input
                type="email"
                value={config.email}
                onChange={(e) => setConfig({ ...config, email: e.target.value })}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Endereço Sede</label>
            <input
              type="text"
              value={config.address}
              onChange={(e) => setConfig({ ...config, address: e.target.value })}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs shadow-xs"
            >
              Salvar Alterações
            </button>
          </div>
        </form>
      </div>

      {/* Theme & Visual Settings */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
          Aparência Visual & Tema
        </h3>

        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-900 dark:text-slate-100">Modo Escuro / Claro</div>
            <div className="text-xs text-slate-500">Alterne instantaneamente o tema visual da aplicação.</div>
          </div>

          <button
            onClick={onToggleTheme}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-900 dark:text-slate-100 font-bold rounded-xl text-xs flex items-center gap-2 cursor-pointer border border-slate-200 dark:border-slate-700"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            <span>{isDarkMode ? 'Mudar para Claro' : 'Mudar para Escuro'}</span>
          </button>
        </div>
      </div>

      {/* Backup & Database JSON Restore */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-2">
          Backup e Restauração de Dados
        </h3>

        <p className="text-xs text-slate-500">
          Exporte todo o banco de dados do CMM (cinemas, salas, relatórios, cadastros e logs) para um arquivo JSON de segurança ou restaure dados gravados.
        </p>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handleExportBackup}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-xs cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Fazer Backup do Banco (JSON)</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center gap-2 border border-slate-700 cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Restaurar Backup JSON</span>
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleImportBackup}
            className="hidden"
          />
        </div>
      </div>
    </div>
  );
};
