import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { MaintenanceReport, CompanyConfig } from '../types';

export async function generateReportPDF(
  report: MaintenanceReport,
  company: CompanyConfig,
  qrCodeDataUrl?: string
): Promise<void> {
  // Create an off-screen container for rendering high-precision HTML
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.top = '-9999px';
  container.style.left = '-9999px';
  container.style.width = '800px';
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.fontFamily = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  container.style.padding = '32px';
  container.style.boxSizing = 'border-box';

  const typeColorMap: Record<string, string> = {
    Preventiva: '#0284c7', // sky-600
    Corretiva: '#d97706', // amber-600
    Emergencial: '#dc2626', // red-600
    Inspeção: '#16a34a', // green-600
  };

  const statusColorMap: Record<string, { bg: string; text: string }> = {
    Funcionando: { bg: '#dcfce7', text: '#15803d' },
    'Funcionando com restrições': { bg: '#fef3c7', text: '#b45309' },
    'Necessita reparo': { bg: '#ffedd5', text: '#c2410c' },
    Parado: { bg: '#fee2e2', text: '#b91c1c' },
  };

  const equipmentRowsHtml = report.equipmentItems
    .map((item, idx) => {
      const st = statusColorMap[item.status] || { bg: '#f1f5f9', text: '#475569' };
      const catName =
        item.category === 'projetor'
          ? 'Projetor'
          : item.category === 'servidor'
          ? 'Servidor'
          : item.category === 'processador'
          ? 'Proc. Áudio'
          : item.category === 'automacao'
          ? 'Automação'
          : 'Outros';

      return `
      <tr style="border-bottom: 1px solid #e2e8f0; font-size: 12px;">
        <td style="padding: 10px 8px; font-weight: 600; color: #334155;">#${idx + 1} - ${catName}</td>
        <td style="padding: 10px 8px; font-weight: 700; color: #0f172a;">${item.model}</td>
        <td style="padding: 10px 8px; color: #64748b; font-size: 11px;">
          ${item.assetNumber ? `Pat: ${item.assetNumber}<br/>` : ''}
          ${item.serialNumber ? `S/N: ${item.serialNumber}` : 'N/A'}
        </td>
        <td style="padding: 10px 8px; color: #334155; max-width: 200px;">${item.description}</td>
        <td style="padding: 10px 8px; color: #475569;">${item.partsReplaced || 'Nenhuma'}</td>
        <td style="padding: 10px 8px; text-align: center; color: #475569;">${item.timeSpentMinutes} min</td>
        <td style="padding: 10px 8px; text-align: center;">
          <span style="display: inline-block; padding: 4px 8px; border-radius: 9999px; font-size: 10px; font-weight: 700; background-color: ${st.bg}; color: ${st.text}; border: 1px solid ${st.text}22;">
            ${item.status}
          </span>
        </td>
      </tr>
    `;
    })
    .join('');

  const photosHtml =
    report.photos && report.photos.length > 0
      ? `
    <div style="margin-top: 24px;">
      <h3 style="font-size: 14px; font-weight: 700; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
        Evidências Fotográficas (${report.photos.length})
      </h3>
      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
        ${report.photos
          .map(
            (photo, pIdx) => `
          <div style="border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; background-color: #f8fafc; text-align: center;">
            <img src="${photo}" style="width: 100%; height: 130px; object-fit: cover; display: block;" />
            <div style="padding: 4px; font-size: 10px; color: #64748b; font-weight: 600; background: #ffffff;">Foto ${pIdx + 1}</div>
          </div>
        `
          )
          .join('')}
      </div>
    </div>
  `
      : '';

  const signatureHtml = report.digitalSignature
    ? `
    <div style="border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; background-color: #fafafa; text-align: center; width: 220px;">
      <img src="${report.digitalSignature}" style="max-height: 60px; max-width: 200px; object-fit: contain; display: block; margin: 0 auto 6px auto;" />
      <div style="font-size: 11px; font-weight: 700; color: #0f172a; border-top: 1px solid #cbd5e1; padding-top: 4px;">${report.technicianName}</div>
      <div style="font-size: 10px; color: #64748b;">Técnico Responsável</div>
    </div>
  `
    : `
    <div style="border: 1px dashed #cbd5e1; border-radius: 8px; padding: 16px; text-align: center; width: 220px; color: #94a3b8; font-size: 11px;">
      Sem Assinatura Digital
    </div>
  `;

  container.innerHTML = `
    <!-- HEADER -->
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #0284c7; padding-bottom: 16px; margin-bottom: 20px;">
      <div>
        <div style="font-size: 20px; font-weight: 900; color: #0f172a; letter-spacing: -0.5px;">${company.name}</div>
        <div style="font-size: 11px; color: #64748b; margin-top: 4px;">
          CNPJ: ${company.cnpj} | Tel: ${company.phone}<br/>
          ${company.address}
        </div>
      </div>
      <div style="text-align: right; display: flex; align-items: center; gap: 12px;">
        <div>
          <div style="display: inline-block; padding: 4px 10px; background: #0284c7; color: #ffffff; border-radius: 6px; font-weight: 800; font-size: 12px; letter-spacing: 0.5px;">
            ${report.id}
          </div>
          <div style="font-size: 10px; color: #64748b; margin-top: 4px; font-weight: 600;">Emissão: ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
        </div>
        ${qrCodeDataUrl ? `<img src="${qrCodeDataUrl}" style="width: 56px; height: 56px; border-radius: 4px; border: 1px solid #e2e8f0;" />` : ''}
      </div>
    </div>

    <!-- REPORT TITLE -->
    <div style="background-color: #f1f5f9; border-left: 4px solid #0284c7; padding: 12px 16px; border-radius: 0 8px 8px 0; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h2 style="margin: 0; font-size: 16px; font-weight: 800; color: #0f172a; text-transform: uppercase;">
          Relatório de Manutenção de Cinema
        </h2>
        <div style="font-size: 12px; color: #475569; margin-top: 2px;">
          Tipo: <strong style="color: ${typeColorMap[report.maintenanceType] || '#0f172a'};">${report.maintenanceType}</strong> | Status: <strong style="color: #16a34a;">${report.status === 'submitted' ? 'CONCLUÍDO & ENVIADO' : 'RASCUNHO'}</strong>
        </div>
      </div>
      <div style="font-size: 12px; font-weight: 700; color: #334155; text-align: right;">
        Data: ${report.date}<br/>Hora: ${report.time}
      </div>
    </div>

    <!-- METADATA GRID -->
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
      <div>
        <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Cinema / Complexo</div>
        <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 2px;">${report.cinemaName}</div>
      </div>
      <div>
        <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Sala / Tecnologia</div>
        <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 2px;">${report.salaName} (${report.salaType})</div>
      </div>
      <div>
        <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Técnico Responsável</div>
        <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 2px;">${report.technicianName}</div>
      </div>
      <div>
        <div style="font-size: 10px; font-weight: 700; color: #64748b; text-transform: uppercase;">Identificador Único</div>
        <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-top: 2px; font-family: monospace;">${report.id}</div>
      </div>
    </div>

    <!-- GENERAL DESCRIPTION -->
    <div style="margin-bottom: 20px;">
      <h3 style="font-size: 13px; font-weight: 700; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">
        Descrição Geral das Atividades
      </h3>
      <div style="font-size: 12px; line-height: 1.6; color: #334155; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; white-space: pre-line;">
        ${report.generalDescription || 'Nenhuma observação geral inserida.'}
      </div>
    </div>

    <!-- EQUIPMENT CHECKLIST -->
    <div style="margin-bottom: 24px;">
      <h3 style="font-size: 13px; font-weight: 700; color: #1e293b; border-bottom: 2px solid #e2e8f0; padding-bottom: 4px; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
        Equipamentos Atendidos (${report.equipmentItems.length})
      </h3>
      <table style="width: 100%; border-collapse: collapse; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden;">
        <thead>
          <tr style="background-color: #0f172a; color: #ffffff; font-size: 11px; text-align: left;">
            <th style="padding: 8px;">Item</th>
            <th style="padding: 8px;">Modelo</th>
            <th style="padding: 8px;">Pat / Série</th>
            <th style="padding: 8px;">Descrição do Serviço</th>
            <th style="padding: 8px;">Peças Substituídas</th>
            <th style="padding: 8px; text-align: center;">Tempo</th>
            <th style="padding: 8px; text-align: center;">Status Final</th>
          </tr>
        </thead>
        <tbody>
          ${equipmentRowsHtml}
        </tbody>
      </table>
    </div>

    <!-- PHOTOS -->
    ${photosHtml}

    <!-- FOOTER & SIGNATURE -->
    <div style="margin-top: 32px; border-top: 2px solid #e2e8f0; padding-top: 16px; display: flex; justify-content: space-between; align-items: flex-end;">
      <div>
        <div style="font-size: 10px; color: #475569; font-weight: 700;">
          CalibraCine • Sistema de Calibração e Manutenção de Cinema
        </div>
        <div style="font-size: 10px; color: #64748b; margin-top: 2px;">
          Criado e desenvolvido por Ronald Ramos | Autenticidade: ${report.id}-${Date.now().toString(36).toUpperCase()}
        </div>
      </div>
      <div>
        ${signatureHtml}
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pdfHeight;

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
    }

    pdf.save(`Relatorio_CalibraCine_${report.id}.pdf`);
  } catch (error) {
    console.error('Error rendering PDF:', error);
    // Fallback printable window
    const printWin = window.open('', '_blank');
    if (printWin) {
      printWin.document.write(`<html><head><title>Relatório ${report.id}</title></head><body>${container.innerHTML}</body></html>`);
      printWin.document.close();
      printWin.focus();
      printWin.print();
    }
  } finally {
    document.body.removeChild(container);
  }
}
