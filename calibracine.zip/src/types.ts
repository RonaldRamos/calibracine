export type Role = 'admin' | 'technician';

export type UserStatus = 'ativo' | 'inativo';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  phone?: string;
  avatar?: string;
  specialty?: string;
  status: UserStatus;
  createdAt: string;
}

export type CinemaStatus = 'ativo' | 'inativo';

export interface Cinema {
  id: string;
  name: string;
  city: string;
  state: string;
  address: string;
  phone: string;
  email: string;
  notes?: string;
  status: CinemaStatus;
  createdAt: string;
}

export type SalaType = 'Convencional' | 'Premium' | 'IMAX' | 'VIP' | 'Laser';

export interface Sala {
  id: string;
  cinemaId: string;
  cinemaName?: string;
  number: number;
  name: string;
  type: SalaType;
  notes?: string;
  createdAt: string;
}

export type EquipmentCategory = 'projetor' | 'servidor' | 'processador' | 'automacao' | 'outros';

export interface EquipmentCategoryInfo {
  id: EquipmentCategory;
  label: string;
  description: string;
  iconName: string;
}

export interface EquipmentModel {
  id: string;
  category: EquipmentCategory;
  brand: string;
  model: string;
  cinemaId?: string; // ID do cinema ao qual o equipamento pertence (ou vazio para todos)
  cinemaName?: string;
  serialNumber?: string;
  description?: string;
}

export type EquipmentStatus = 'Funcionando' | 'Funcionando com restrições' | 'Necessita reparo' | 'Parado';

export interface EquipmentMaintenanceItem {
  id: string;
  category: EquipmentCategory;
  model: string;
  assetNumber?: string;
  serialNumber?: string;
  description: string;
  partsReplaced?: string;
  timeSpentMinutes: number;
  status: EquipmentStatus;
}

export type MaintenanceType = 'Preventiva' | 'Corretiva' | 'Emergencial' | 'Inspeção';

export type ReportStatus = 'draft' | 'submitted';

export interface MaintenanceReport {
  id: string; // e.g., CMM-2026-001
  technicianId: string;
  technicianName: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  cinemaId: string;
  cinemaName: string;
  salaId: string;
  salaName: string;
  salaType: SalaType;
  maintenanceType: MaintenanceType;
  generalDescription: string;
  equipmentItems: EquipmentMaintenanceItem[];
  photos: string[]; // Base64 or URL
  digitalSignature?: string; // PNG Base64
  status: ReportStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  userRole: Role;
  action: string;
  details: string;
  timestamp: string;
}

export interface CompanyConfig {
  name: string;
  cnpj: string;
  logoUrl?: string;
  phone: string;
  email: string;
  address: string;
  theme: 'light' | 'dark' | 'auto';
  language: 'pt-BR' | 'en' | 'es';
  backupAuto: boolean;
}

export interface ReportFilter {
  startDate?: string;
  endDate?: string;
  cinemaId?: string;
  salaId?: string;
  technicianId?: string;
  category?: EquipmentCategory | 'all';
  maintenanceType?: MaintenanceType | 'all';
  status?: ReportStatus | 'all';
  searchQuery?: string;
}

export interface DashboardStats {
  totalCinemas: number;
  totalSalas: number;
  totalTechnicians: number;
  totalReports: number;
  reportsToday: number;
  reportsThisMonth: number;
  totalEquipments: number;
  totalPhotos: number;
}
